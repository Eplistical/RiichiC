def init_stats(player_name):
    return {
        'player_name': player_name,
        'games_count': 0,
        'hand_count': 0,
        'place_count_map': { k: 0 for k in range(1,5)},
        'top_k_count_map': { k: 0 for k in range(1,5)},
        'rank_sum': 0,
        'max_points': None,
        'points_sum': 0,
        'points_sum_with_uma': 0,
        'riichi_sum': 0,
        'agari_sum': 0,
        'deal_in_sum': 0,
        'agari_pt_sum': 0,
        'deal_in_pt_sum': 0,
        'chombo_sum': 0,
    }

def aggregate_player_stats(aggregated_stats, player_stats, game):
    """helper function that aggregates a player's stats from a single hand"""
    print(f'Aggregating {player_stats}')
    player_name = player_stats['name']
    if player_name not in aggregated_stats:
        aggregated_stats[player_name] = init_stats(player_name)
    # game count
    aggregated_stats[player_name]['games_count'] += 1
    # hand count
    aggregated_stats[player_name]['hand_count'] += game['game_hand_count']
    # rank count
    aggregated_stats[player_name]['place_count_map'][player_stats['rank']] += 1
    # top k count
    for k in range(player_stats['rank'], 5):
        aggregated_stats[player_name]['top_k_count_map'][k] += 1
    # rank sum
    aggregated_stats[player_name]['rank_sum'] += player_stats['rank']
    # max pt
    if aggregated_stats[player_name]['max_points'] is None or aggregated_stats[player_name]['max_points'] < player_stats['points']:
        aggregated_stats[player_name]['max_points'] = player_stats['points']
    # points sum
    aggregated_stats[player_name]['points_sum'] += player_stats['points']
    # points sum with (adjusted) uma
    aggregated_stats[player_name]['points_sum_with_uma'] += player_stats['points_with_uma']
    # riichi sum
    aggregated_stats[player_name]['riichi_sum'] += player_stats['riichi']
    # agari sum
    aggregated_stats[player_name]['agari_sum'] += player_stats['agari']
    # deal-in sum
    aggregated_stats[player_name]['deal_in_sum'] += player_stats['deal_in']
    # chombo sum
    aggregated_stats[player_name]['chombo_sum'] += player_stats['chombo']
    # agari pt sum
    aggregated_stats[player_name]['agari_pt_sum'] += player_stats['agari_pt_sum']
    # deal-in pt sum
    aggregated_stats[player_name]['deal_in_pt_sum'] += player_stats['deal_in_pt_sum']
