import boto3
from boto3.dynamodb.types import TypeDeserializer
from boto3.dynamodb.types import TypeSerializer
from boto3.dynamodb.conditions import Key, Attr, And, Or, Between
from functools import reduce
from uuid import uuid4
from util import resolve_ranks
from util import get_adjusted_uma
from stats import aggregate_player_stats
import json
import hashlib
import traceback
from urllib import parse
from datetime import datetime, timezone
from dateutil import tz

GAMES_TABLE = 'riichi-stats-games-data'
GAMES_TABLE_MAP = {
    'THE_3Q1_LEAGUE': 'riichi-stats-games-data',
    'PHI_LEAGUE': 'riichi-stats-games-data-phi-league'
}
PLAYERS_TABLE = 'riichi-stats-players'
ADMIN_TABLE = 'riichi-stats-admin'
dynamo = boto3.client('dynamodb')
serializer = TypeSerializer()
deserializer = TypeDeserializer()
WINDS = ('east', 'south', 'west', 'north')
DEFAULT_RULE_SET = 'THE_3Q1_LEAGUE'
RULE_SET_MAP = {
    'THE_3Q1_LEAGUE': {
        'starting_points': 25000,
        'uma': (45,5,-15,-35),
    },
    'PHI_LEAGUE': {
        'starting_points': 30000,
        'uma': (30,10,-10,-30),
    }
}

BLOCKED_PLAYER_NAME = "sub"

def dynamo_to_python(item):
    if "NULL" in item:
        # null
        return None
    elif "N" in item:
        # number
        return float(item["N"])
    elif "S" in item:
        # string
        return item["S"]
    elif "BOOL" in item:
        # boolean
        return bool(item["BOOL"])
    elif "B" in item:
        # binary
        return item["B"]
    elif "L" in item:
        # list
        return [dynamo_to_python(x) for x in item["L"]]
    elif "M" in item:
        # map
        return {
            k: dynamo_to_python(v)
            for k, v in item["M"].items()
        }
    else:
        raise KeyError(f"dynamo_to_python: Cannot convert item {item}")

def game_db_item_to_dict(item, uma):
    """Convert db item of a game to a dict"""
    game = {
        "game_id": item["game_id"]["S"],
        "game_date": int(item["game_date"]["N"]),
        "game_logs": dynamo_to_python(item["game_logs"]) if 'game_logs' in item else None,
        "record_timestamp": item["record_timestamp"]["S"],
        "game_hand_count": int(item['game_hand_count']['N']) if 'game_hand_count' in item else 0,
    }
    for wind in WINDS:
        game[wind] = {
            'name': item[f'{wind}_player_name']['S'],
            'points': int(item[f'{wind}_player_points']['N']),
            'riichi': int(item[f'{wind}_player_riichi']['N']),
            'agari': int(item[f'{wind}_player_agari']['N']),
            'deal_in': int(item[f'{wind}_player_deal_in']['N']),
            'tenpai_on_draw': int(item[f'{wind}_tenpai_on_draw']['N']) if f'{wind}_tenpai_on_draw' in item else 0,
            'chombo': int(item[f'{wind}_chombo']['N']) if f'{wind}_chombo' in item else 0,
            'agari_pt_sum': int(item[f'{wind}_player_agari_pt_sum']['N']) if f'{wind}_player_agari_pt_sum' in item else 0,
            'deal_in_pt_sum': int(item[f'{wind}_player_deal_in_pt_sum']['N']) if f'{wind}_player_deal_in_pt_sum' in item else 0,
        }
    ranks = resolve_ranks([game[wind]['points'] for wind in WINDS])
    adjusted_uma = get_adjusted_uma(ranks, uma)
    for i, wind in enumerate(WINDS):
        game[wind]['rank'] = ranks[i]
        game[wind]['points_with_uma'] = game[wind]['points'] + adjusted_uma[ranks[i]-1] * 1000
    return game

def game_dict_to_db_item(game, admin_id):
    """Convert a game dict to db item"""
    item = {
        'game_date': game['game_date'],
        'game_hand_count': game.get('game_hand_count', 0),
        'game_logs': game.get('game_logs', None)
    }
    for wind in WINDS:
        item[f'{wind}_player_name'] = game[wind]['name']
        item[f'{wind}_player_points'] = game[wind]['points']
        item[f'{wind}_player_riichi'] = game[wind]['riichi']
        item[f'{wind}_player_agari'] = game[wind]['agari']
        item[f'{wind}_player_deal_in'] = game[wind]['deal_in']
        item[f'{wind}_tenpai_on_draw'] = game[wind].get('tenpai_on_draw', 0)
        item[f'{wind}_chombo'] = game[wind].get('chombo', 0)
        item[f'{wind}_player_agari_pt_sum'] = game[wind]['agari_pt_sum']
        item[f'{wind}_player_deal_in_pt_sum'] = game[wind]['deal_in_pt_sum']
        
    if 'game_id' in game:
        item['game_id'] = game['game_id']
    if 'record_timestamp' in game:
        item['record_timestamp'] = game['record_timestamp']
    item['admin_id'] = admin_id
    return serializer.serialize(item)['M']
    
def list_players(include_fake=False, ruleset_ids=None):
    """get a list of all player names in the db"""
    # Get all players as well as applicable rulesets
    rst = dynamo.scan(TableName=PLAYERS_TABLE)
    players_blocked_ruleset_ids_map = {
        p["player_name"]["S"]: p["blocked_ruleset_ids"]["SS"] if "blocked_ruleset_ids" in p else []
        for p in rst["Items"]
    }
    all_players = list(players_blocked_ruleset_ids_map.keys())
    # If we do not set ruleset_id param, fetch all rulesets
    if ruleset_ids is None:
        ruleset_ids = ['CUSTOM'] + list(RULE_SET_MAP.keys())
    # construct result ruleset=>registered_players map
    players = {}
    for ruleset_id in ruleset_ids:
        filtered_players = filter(lambda p: ruleset_id not in players_blocked_ruleset_ids_map[p], all_players)
        if not include_fake:
            filtered_players = filter(lambda p: not p.startswith('__'), filtered_players)
        players[ruleset_id] = sorted(filtered_players)
    return players
    
def get_admin_info(token, ruleset_id):
    """get admin id for a given token"""
    sha1 = hashlib.sha1()
    sha1.update(bytes(token, 'utf-8'))
    token_sha1 = sha1.hexdigest()
    #print('token = ', token, ' sha1 = ', token_sha1)
    filter_expression = '(token_sha1=:token_sha1) AND (ruleset_id=:ruleset_id)'
    expression_attribute_values = {
        ":token_sha1": token_sha1,
        ":ruleset_id": ruleset_id
    }
    response = dynamo.scan(TableName=ADMIN_TABLE, ProjectionExpression='admin_id, ruleset_id',
        FilterExpression=filter_expression,
        ExpressionAttributeValues=serializer.serialize(expression_attribute_values)['M'])
    return None if len(response['Items']) == 0 else {'admin_id': response['Items'][0]['admin_id']['S'], 'ruleset_id': response['Items'][0]['ruleset_id']['S']}

def record_game(game, admin_info):
    """record a game"""
    print(f'Recording game {game}')
    # make sure all players are registered
    ruleset_id = admin_info['ruleset_id']
    registered_players = list_players(include_fake=True, ruleset_ids=[ruleset_id])[ruleset_id]
    unregistered_players = []
    players = [game[wind]['name'] for wind in WINDS] 
    for p in players:
        if p not in registered_players:
            unregistered_players.append(p)
    if len(unregistered_players) > 0:
        return {
            'statusCode': 400,
            'body': f'Unregistered player {unregistered_players}'
        }
    if len(players) > len(set(players)):
        return {
            'statusCode': 400,
            'body': f'Duplicate players found.'
        }
    # generate a game ID
    game["game_id"] = str(uuid4())
    game["record_timestamp"] = datetime.now(tz=tz.gettz('US/Eastern')).strftime("%m/%d/%Y %H:%M:%S")
    item = game_dict_to_db_item(game, admin_info['admin_id'])
    rst = dynamo.put_item(TableName=GAMES_TABLE_MAP[ruleset_id], Item=item)
    return {
        'statusCode': 200,
        'body': json.dumps({'game_id': game['game_id']})
    }
    
def hide_invalid_player_names(games, ruleset_id):
    registered_players = set(list_players(include_fake=True, ruleset_ids=[ruleset_id])[ruleset_id])
    for game in games:
        for wind in WINDS:
            if game[wind]['name'] not in registered_players:
                game[wind]['name'] = BLOCKED_PLAYER_NAME
    return games
    
def list_games(ruleset_id, player_name=None, start_date=0, end_date=99999999):
    """list games"""
    #print(f'Listing games: ruleset_id={ruleset_id} player_name={player_name}, start_date={start_date}, end_date={end_date}')
    ruleset = RULE_SET_MAP[ruleset_id]
    #print(f'Resolved ruleset = {ruleset}')
    filter_expression = '(game_date BETWEEN :start_date AND :end_date)'
    expression_attribute_values = {
        ":start_date": start_date,
        ":end_date": end_date,
    }
    if player_name is not None:
        filter_expression += ' AND (east_player_name = :player_name OR south_player_name = :player_name OR west_player_name = :player_name OR north_player_name = :player_name)'
        expression_attribute_values[':player_name'] = player_name
    rst = dynamo.scan(TableName=GAMES_TABLE_MAP[ruleset_id], 
        FilterExpression=filter_expression,
        ExpressionAttributeValues=serializer.serialize(expression_attribute_values)['M'])
    games = [game_db_item_to_dict(game, ruleset['uma']) for game in rst['Items']]
    games = hide_invalid_player_names(games, ruleset_id)
    games = sorted(games, key=lambda game: (game['game_date'], datetime.strptime(game['record_timestamp'], '%m/%d/%Y %H:%M:%S')), reverse=True)
    return games


def get_stats(ruleset_id, player_name=None, start_date=0, end_date=99999999):
    """computes aggregated stast and for some games"""
    ruleset = RULE_SET_MAP[ruleset_id]
    print(f'Getting stats: player_name={player_name}, start_date={start_date}, end_date={end_date} ruleset = {ruleset}')
    games = list_games(ruleset_id=ruleset_id, player_name=player_name, start_date=start_date, end_date=end_date)
    aggregated_stats = dict()
    for game in games:
        for idx, wind in enumerate(WINDS):
            aggregate_player_stats(aggregated_stats, game[wind], game, ruleset)
    if BLOCKED_PLAYER_NAME in aggregated_stats:
        del aggregated_stats[BLOCKED_PLAYER_NAME]
    if player_name is not None:
        return [aggregated_stats[player_name]]
    else:
        return sorted(aggregated_stats.values(), key=lambda s: (s['points_sum_with_uma'] - s['games_count'] * ruleset['starting_points'] ), reverse=True)
        
    
def lambda_handler(event, context):
    try:
        http_method = event.get('requestContext', {}).get('http', {}).get('method', '')
        if http_method == 'GET':
            params = event.get('queryStringParameters', {})
            print(f'GET WITH params: {params}')
            action = params.get('action', None)
            if action == 'list_games':
                start_date = int(params.get('start_date', 0))
                end_date = int(params.get('end_date', 99999999))
                player_name = params.get('player_name', None)
                ruleset_id = params.get('ruleset_id', DEFAULT_RULE_SET)
                games = list_games(ruleset_id, player_name=player_name, start_date=start_date, end_date=end_date)
                body = {
                    'start_date': start_date,
                    'end_date': end_date,
                    'count': len(games),
                    'games': games
                }
                resp = {
                    "statusCode": 200,
                    "body": json.dumps(body)
                }
            elif action == 'get_stats':
                start_date = int(params.get('start_date', 0))
                end_date = int(params.get('end_date', 99999999))
                player_name = params.get('player_name', None)
                ruleset_id = params.get('ruleset_id', DEFAULT_RULE_SET)
                stats = get_stats(ruleset_id, player_name=player_name, start_date=start_date, end_date=end_date)
                body = {
                    'count': len(stats),
                    'start_date': start_date,
                    'end_date': end_date,
                    'stats': stats,
                }
                resp = {
                    'statusCode': 200,
                    'body': json.dumps(body),
                }
            elif action == 'list_players':
                players = list_players()
                body = {
                    'players': players
                }
                resp = {
                    'statusCode': 200,
                    'body': json.dumps(body)
                }
            else:
                resp = {
                    'statusCode': 400,
                    'body': json.dumps(f'Unsupported GET action {action}')
                }
        elif http_method == 'POST':
            params = event['body']
            print(f'POST params: {params}')
            if type(params) == str:
                params = json.loads(params)
            action = params['action']
            if action == 'record_game':
                token = params.get('token', '')
                ruleset_id = params.get('ruleset_id', '')
                admin_info = get_admin_info(token, ruleset_id)
                if admin_info is None:
                    resp = {
                        'statusCode': 400,
                        'body': json.dumps('Unauthorized token.')
                    }
                else:
                    resp = record_game(params['game'], admin_info)
            else:
                resp = {
                    'statusCode': 400,
                    'body': json.dumps(f'Unsupported POST action {action}')
                }
        else:
            print(f'Unrecognized http_method = {http_method}')
            resp = {
                'statusCode': 400,
                'body': f'invalid http method {http_method}'
            }
        print(f'Response = {resp}')
        return resp
    except Exception as e:
        print(e)
        traceback.print_exc()
        tb = e.__traceback__
        tbt = ''
        while tb:
            tbt += f'{tb.tb_frame.f_code.co_filename}: {tb.tb_lineno}\n'
            tb = tb.tb_next
        return {
            'statusCode': 500,
            'body': f'error caught: {e}, traceback: {tbt}'
        }